import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Button from "react-bootstrap/Button";
import Dropdown from "react-bootstrap/Dropdown";
import DropdownButton from "react-bootstrap/DropdownButton";
import SignUp from "../components/newsLetter/SignUp";

import BuildReference from "../components/HomeScreen/HomeSection";

// Creating a User component to be exported to App.jsx

function FirstPage({
    
    headline, 
    intro, 
    choice, 
    delivery, 
    cookery,
    mobile_app, 
    week_menu,
    order,
    get_started, 
    going_pro,
    chef_picture, 
    chef,
    food_team,
    veg_picture,
    fresh,
    ethics,
    delivery_mode,
    subscription,
    kit_pause,
    holiday,
    kit_picture,
    menu,
    balsamic_duck_breast,
    beef_pancake,
    beecon_charred_tomat,
    herb_rice_pilaf,
    basil_pesto_beans,
    spicy_ostrich,
    chermoula_salsa,
    pervian_ostrich,
    commitment,
    support,
    homegrown,
    story,
    product,
    company,
    support2,
    social1,
    social2,
    social3,
    social4,
    social5,
    social6}) {
    return (
        // creating an instance of the container to automate the layout.
        <Container fluid>
        <div style={{backgroundColor: "rgb(250, 250, 250)"}}>
            <Row>
                <Col className="background"><br /><br /><br /><br /><br /><br />
                <h4><b>{headline}</b></h4>
                {intro}<br /><br />
                <a href="https://www.ucook.co.za/meal-kit/"><Button>SEE THIS WEEK'S MENU</Button></a></Col>
            </Row>
            <div id="section1">
                <br /><br />
                <h5>How it Works</h5>
                <div id="myrow">
                    <div style={{borderRadius: 15}}><h6>You Choose</h6><br /> {choice}</div>
                    <div style={{borderRadius: 15}}><h6>We Deliver</h6><br /> {delivery}</div>
                    <div style={{borderRadius: 15}}><h6>You Cook</h6><br /> {cookery}</div>
                </div>
            </div>
            <br />
            <div id="section2">
                <br />
                <h5 id="sectionh5">Sorting out mealtimes is simple again</h5>
                <br />
                <h3 id="sectionh3">Try Meal Kits and get what you need, delivered.</h3>
                <br />
                <h6 id="sectionh7">Feeling uninspired? Our chefs are here to help. Every week, we design 28 new dinner and 4 new lunch dishes that you can pick from, and deliver what you need to prepare them.</h6>
            </div>
            <div id="section3">
                <div id="mobile">{mobile_app}</div>
                <div style={{justifyContent: "right"}}><br /><br /><br /><br /><br />
                    <div style={{color: "gray", fontSize: "large", fontWeight: "bold"}}>{week_menu}</div><br />
                    <div style={{fontSize: "x-large", fontFamily: "sans-serif", fontWeight: "bold"}}>{order}</div><br />
                    <div>{get_started}</div>
                </div>
            </div>
            <div id="section4">
                <div><br /><br /><br /><br />
                    <div style={{color: "gray", fontSize: "large", fontWeight: "bold"}}>{going_pro}</div><br />
                    <div style={{fontSize: "x-large", fontFamily: "sans-serif", fontWeight: "bold"}}>{chef}</div><br />
                    <div>{food_team}</div>
                </div>
                <div id="service">{chef_picture}</div>
            </div>
            <div id="section5">
                <div id="vegpicture">{veg_picture}</div>
                <div style={{justifyContent: "right"}}><br /><br /><br /><br /><br />
                    <div style={{color: "gray", fontSize: "large", fontWeight: "bold"}}>{fresh}</div><br />
                    <div style={{fontSize: "x-large", fontFamily: "sans-serif", fontWeight: "bold"}}>{ethics}</div><br />
                    <div>{delivery_mode}</div>
                </div>
            </div>
            <div id="section6">
                <div><br /><br /><br /><br />
                    <div style={{color: "gray", fontSize: "large", fontWeight: "bold"}}>{subscription}</div><br />
                    <div style={{fontSize: "x-large", fontFamily: "sans-serif", fontWeight: "bold"}}>{kit_pause}</div><br />
                    <div>{holiday}</div>
                </div>
                <div id="kit">{kit_picture}</div>
            </div>
            <div><br /><br /><br /><br />
                <div style={{color: "gray", fontSize: "x-large", fontWeight: "bold"}}>{menu}</div>
                <hr />
                <div class="scroll-container">
                    <div class="scrollcard">{balsamic_duck_breast}
                        <DropdownButton id="button8" title="See Menu">
                            <Dropdown.Item href="#/action-1">Service 1</Dropdown.Item>
                            <Dropdown.Item href="#/action-2">Service 2</Dropdown.Item>
                            <Dropdown.Item href="#/action-3">Service 3</Dropdown.Item>
                            <Dropdown.Item href="#/action-4">Service 4</Dropdown.Item>
                        </DropdownButton><br /><br />
                    <Button id="button7"><div style={{fontSize: "small"}}>balsamic_duck_breast</div></Button>
                    <Button id="start1" variant="secondary"><div style={{fontSize: "small"}}>GET STARTED</div></Button>
                    <Button id="extra1" variant="secondary"><div style={{fontSize: "small"}}>ADD EXTRAS</div></Button></div>
                    <div class="scrollcard">{beef_pancake}
                        <DropdownButton id="button9" title="See Menu">
                            <Dropdown.Item href="#/action-1">Service 1</Dropdown.Item>
                            <Dropdown.Item href="#/action-2">Service 2</Dropdown.Item>
                            <Dropdown.Item href="#/action-3">Service 3</Dropdown.Item>
                            <Dropdown.Item href="#/action-4">Service 4</Dropdown.Item>
                        </DropdownButton><br /><br /><br />
                    <Button id="button10"><div style={{fontSize: "small"}}>beef-pancake</div></Button>
                    <Button id="start2" variant="secondary"><div style={{fontSize: "small"}}>GET STARTED</div></Button>
                    <Button id="extra2" variant="secondary"><div style={{fontSize: "small"}}>ADD EXTRAS</div></Button></div>
                    <div class="scrollcard">{beecon_charred_tomat}
                        <DropdownButton id="button9" title="See Menu">
                            <Dropdown.Item href="#/action-1">Service 1</Dropdown.Item>
                            <Dropdown.Item href="#/action-2">Service 2</Dropdown.Item>
                            <Dropdown.Item href="#/action-3">Service 3</Dropdown.Item>
                            <Dropdown.Item href="#/action-4">Service 4</Dropdown.Item>
                        </DropdownButton><br /><br /><br />
                    <Button id="button10"><div style={{fontSize: "small"}}>beecon_tomato</div></Button>
                    <Button id="start2" variant="secondary"><div style={{fontSize: "small"}}>GET STARTED</div></Button>
                    <Button id="extra2" variant="secondary"><div style={{fontSize: "small"}}>ADD EXTRAS</div></Button></div>
                    <div class="scrollcard">{herb_rice_pilaf}
                        <DropdownButton id="button9" title="See Menu">
                            <Dropdown.Item href="#/action-1">Service 1</Dropdown.Item>
                            <Dropdown.Item href="#/action-2">Service 2</Dropdown.Item>
                            <Dropdown.Item href="#/action-3">Service 3</Dropdown.Item>
                            <Dropdown.Item href="#/action-4">Service 4</Dropdown.Item>
                        </DropdownButton><br /><br /><br />
                    <Button id="button10"><div style={{fontSize: "small"}}>herb_rice_pilaf</div></Button>
                    <Button id="start2" variant="secondary"><div style={{fontSize: "small"}}>GET STARTED</div></Button>
                    <Button id="extra2" variant="secondary"><div style={{fontSize: "small"}}>ADD EXTRAS</div></Button></div>
                    <div class="scrollcard">{basil_pesto_beans}
                        <DropdownButton id="button9" title="See Menu">
                            <Dropdown.Item href="#/action-1">Service 1</Dropdown.Item>
                            <Dropdown.Item href="#/action-2">Service 2</Dropdown.Item>
                            <Dropdown.Item href="#/action-3">Service 3</Dropdown.Item>
                            <Dropdown.Item href="#/action-4">Service 4</Dropdown.Item>
                        </DropdownButton><br /><br /><br />
                    <Button id="button10"><div style={{fontSize: "small"}}>basil_pesto_beans</div></Button>
                    <Button id="start2" variant="secondary"><div style={{fontSize: "small"}}>GET STARTED</div></Button>
                    <Button id="extra2" variant="secondary"><div style={{fontSize: "small"}}>ADD EXTRAS</div></Button></div>
                    <div class="scrollcard">{spicy_ostrich}
                        <DropdownButton id="button9" title="See Menu">
                            <Dropdown.Item href="#/action-1">Service 1</Dropdown.Item>
                            <Dropdown.Item href="#/action-2">Service 2</Dropdown.Item>
                            <Dropdown.Item href="#/action-3">Service 3</Dropdown.Item>
                            <Dropdown.Item href="#/action-4">Service 4</Dropdown.Item>
                        </DropdownButton><br /><br /><br />
                    <Button id="button10"><div style={{fontSize: "small"}}>spicy_ostrich</div></Button>
                    <Button id="start2" variant="secondary"><div style={{fontSize: "small"}}>GET STARTED</div></Button>
                    <Button id="extra2" variant="secondary"><div style={{fontSize: "small"}}>ADD EXTRAS</div></Button></div>
                    <div class="scrollcard">{chermoula_salsa}
                        <DropdownButton id="button9" title="See Menu">
                            <Dropdown.Item href="#/action-1">Service 1</Dropdown.Item>
                            <Dropdown.Item href="#/action-2">Service 2</Dropdown.Item>
                            <Dropdown.Item href="#/action-3">Service 3</Dropdown.Item>
                            <Dropdown.Item href="#/action-4">Service 4</Dropdown.Item>
                        </DropdownButton><br /><br /><br />
                    <Button id="button10"><div style={{fontSize: "small"}}>chermoula_salsa</div></Button>
                    <Button id="start2" variant="secondary"><div style={{fontSize: "small"}}>GET STARTED</div></Button>
                    <Button id="extra2" variant="secondary"><div style={{fontSize: "small"}}>ADD EXTRAS</div></Button></div>
                    <div class="scrollcard">{pervian_ostrich}
                        <DropdownButton id="button9" title="See Menu">
                            <Dropdown.Item href="#/action-1">Service 1</Dropdown.Item>
                            <Dropdown.Item href="#/action-2">Service 2</Dropdown.Item>
                            <Dropdown.Item href="#/action-3">Service 3</Dropdown.Item>
                            <Dropdown.Item href="#/action-4">Service 4</Dropdown.Item>
                        </DropdownButton><br /><br /><br />
                    <Button id="button10"><div style={{fontSize: "small"}}>pervian_ostrich</div></Button>
                    <Button id="start2" variant="secondary"><div style={{fontSize: "small"}}>GET STARTED</div></Button>
                    <Button id="extra2" variant="secondary"><div style={{fontSize: "small"}}>ADD EXTRAS</div></Button></div>
                </div>
                <br /><br />
                <div id="section8">
                    <br /><br />
                    <h5>Our Food Philosophy</h5>
                    <div id="myrow">
                        <div style={{borderRadius: 15}}><h6>We Keep It Seasonal</h6><br /> {commitment}</div>
                        <div style={{borderRadius: 15}}><h6>Help Us Put Farmers First</h6><br /> {support}</div>
                        <div style={{borderRadius: 15}}><h6>We’re All About Local</h6><br /> {homegrown}</div>
                    </div>
                </div>
                <div id="section9">
                    <div className="banner2">
                        <div>
                            <div style={{borderRadius: 15}}><h5>Our Story</h5><br /><h3>Making mealtimes better since 2014</h3><br /> {story}</div>
                        </div>
                    </div>
                </div>
                <br />
                <Button id="button12" variant="secondary"><div style={{fontSize: "small"}}>LEARN MORE</div></Button>
            </div>
            <div>
                <SignUp></SignUp>
            </div>
            <Button id="button13" vatiant="info">PRODUCT</Button>
            <Button id="button14" vatiant="info">COMPANY</Button>
            <Button id="button15" vatiant="info">SUPPORT</Button>
            <Button id="button16" vatiant="info">CONNECT</Button>
            <div id="section10">
                <br /><br />
                <div /* id="myrow" */>
                    <h6><div style={{borderRadius: 15}}>Our popular recipe collections.<br /> {product}</div></h6>
                    <h6><div style={{borderRadius: 15}}>All about this company.<br /> {company}</div></h6>
                    <h6><div style={{borderRadius: 15}}> Read FAQ's and get in touch.<br /> {support2}</div></h6>
                    <div style={{borderRadius: 15}}>Connect, share, and tweet.<br />
                        {social1} {social2} {social3} {social4} {social5} {social6}</div>
                </div>
            </div>
            <hr />
            <div className="reflink">
                <Button><BuildReference></BuildReference></Button>
            </div>
            <hr />
        </div>
        </Container>
    );
}

export default FirstPage;