import React from "react"
/* import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import { HashLink } from 'react-router-hash-link' */

import { ExternalLink } from "react-external-link";
import "./Linkstyles.css"

const UcookInspire = () => (         
  <div>
    <ExternalLink id="logo" style={{fontSize: "large", color: "black"}} href="https://www.ucook.co.za/"><img src={"src/Profiles/logo_large.svg"} /></ExternalLink>
  </div>
);

export default UcookInspire;


/* function LinkPages() {
  return (https://www.ucook.co.za/cms/about-meal-kits
    <Router>
    <div>
      <nav>
        <ul>
          <li>
            <a href="/https://www.ucook.co.za/meal-kit">Markets</a>
          </li>
          <li>
            <a href="/https://www.ucook.co.za/cms/about-meal-kits">About</a>
          </li>
          <li>
            <a href="/https://www.ucook.co.za/cms/deals">Deals</a>
          </li>
        </ul>
      </nav>

      <Routes>
        <Route path="/Markets">
          <About />
        </Route>
        <Route path="/About">
      <Users />
        </Route>
        <Route path="/Deals">
          <Home />
        </Route>
      </Routes>
    </div>
    </Router>
  );
}

function Markets() {
return <h2>Markets</h2>;
}

function About() {
return <h2>About</h2>;
}

function Deals() {
return <h2>Deals</h2>;
}

export default LinkPages; */