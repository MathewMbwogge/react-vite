import React from "react";
import { ExternalLink } from "react-external-link";
import "./Linkstyles.css"

const WeekendOffers = () => (         
    <div>
      <ExternalLink id="links" href="https://www.ucook.co.za/market/store/weekend-boxes">WEEKEND BOXES</ExternalLink>
    </div>
  );
  
  export default WeekendOffers;