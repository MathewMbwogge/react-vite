import React from "react";
import { ExternalLink } from "react-external-link";
import "./Linkstyles.css"

const Deals = () => (         
    <div>
      <ExternalLink id="links" href="https://www.ucook.co.za/cms/deals">DEALS</ExternalLink>
    </div>
  );
  
  export default Deals;