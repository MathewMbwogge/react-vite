import React from "react";
import { ExternalLink } from "react-external-link";
import "./Linkstyles.css";

const Gifts = () => (         
    <div>
      <ExternalLink id="links" href="https://www.ucook.co.za/cms/gifts">GIFTS</ExternalLink>
    </div>
  );
  
  export default Gifts;