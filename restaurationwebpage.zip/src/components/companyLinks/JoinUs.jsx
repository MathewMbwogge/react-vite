import React from "react";
import { ExternalLink } from "react-external-link";

const JoinUs = () => (         
    <div>
      <ExternalLink id="links" href="https://www.ucook.co.za/cms/partnerships">PARTNER WITH US</ExternalLink>
    </div>
  );
  
  export default JoinUs;