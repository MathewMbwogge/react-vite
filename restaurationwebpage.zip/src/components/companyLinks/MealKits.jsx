import React from "react";
import { ExternalLink } from "react-external-link";
import "./Linkstyles.css"

const MealKits = () => (         
    <div>
      <ExternalLink id="links" href="https://www.ucook.co.za/meal-kit">MEAL KITS</ExternalLink>
    </div>
  );
  
  export default MealKits;