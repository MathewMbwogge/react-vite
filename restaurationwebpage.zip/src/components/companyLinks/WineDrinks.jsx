import React from "react";
import { ExternalLink } from "react-external-link";
import "./Linkstyles.css";

const WindCatalog = () => (         
    <div>
      <ExternalLink id="links" href="https://www.ucook.co.za/wine">WINE</ExternalLink>
    </div>
  );
  
  export default WindCatalog;