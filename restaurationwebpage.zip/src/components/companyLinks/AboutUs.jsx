import React from "react";
import { ExternalLink } from "react-external-link";
import "./Linkstyles.css"

const AboutUs = () => (         
    <div>
      <ExternalLink id="links" href="https://www.ucook.co.za/cms/about-meal-kits">ABOUT UCOOK</ExternalLink>
    </div>
  );
  
  export default AboutUs;