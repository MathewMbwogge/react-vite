import React from "react";
import { ExternalLink } from "react-external-link";
import "./Linkstyles.css"

const FrozenFood = () => (
    <div>
      <ExternalLink id="links" href="https://www.ucook.co.za/frozen">FROZEN</ExternalLink>
    </div>
  );
  
  export default FrozenFood;
