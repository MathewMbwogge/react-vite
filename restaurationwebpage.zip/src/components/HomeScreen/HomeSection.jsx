import React from "react";
import { ExternalLink } from "react-external-link";

const BuildReference = () => (         
  <div>
    <ExternalLink style={{color: "white"}} href="https://www.ucook.co.za/">UCOOK</ExternalLink>
  </div>
);

export default BuildReference;