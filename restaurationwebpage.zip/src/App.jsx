console.log("")

import "./App.css";
import Button from "react-bootstrap/Button";

// Loading Media Pages
import UcookInspire from "./components/companyLinks/LinktoUcook";
import MealKits from "./components/companyLinks/MealKits";
import FrozenFood from "./components/companyLinks/FrozenFood";
import WindDrinks from "./components/companyLinks/WineDrinks";
import SoldRecipes from "./components/companyLinks/SoldRecipes";
import WeekendOffers from "./components/companyLinks/WeekendOffers"
import AboutUs from "./components/companyLinks/AboutUs";
import JoinUs from "./components/companyLinks/JoinUs";
import FreeGifts from "./components/companyLinks/FreeGits";
import Deals from "./components/companyLinks/Deals"

// importing components
import FirstPage from "./pages/firstPage";
import section3Picture from "./Profiles/icon1.png";
import section4Picture from "./Profiles/icon2.png";
import section5Picture from "./Profiles/icon3.png";
import section6Picture from "./Profiles/icon4.png";
import section7Picture1 from "./Profiles/img1.png";
import section7Picture2 from "./Profiles/img2.png";
import section7Picture3 from "./Profiles/img3.png";
import section7Picture4 from "./Profiles/img4.jpg";
import section7Picture5 from "./Profiles/img5.png";
import section7Picture6 from "./Profiles/img6.png";
import section7Picture7 from "./Profiles/img7.png";
import section7Picture8 from "./Profiles/img8.png";
import section10Picture1 from "./Profiles/appstore.svg";
import section10Picture2 from "./Profiles/playstore.png";
import section10Picture3 from "./Profiles/facebook.png";
import section10Picture4 from "./Profiles/Linkedin.png";
import section10Picture5 from "./Profiles/x-logo.png";
import section10Picture6 from "./Profiles/youtube.png";

function App() {
  return (
    <>
    <div class="root">
      <div id="header">
        <UcookInspire></UcookInspire>
        <Button style={{backgroundColor: "white", border: "none"}}><MealKits></MealKits></Button>
        <Button style={{backgroundColor: "white", border: "none"}}><FrozenFood></FrozenFood></Button>
        <Button style={{backgroundColor: "white", border: "none"}}><WindDrinks></WindDrinks></Button>
        <Button style={{backgroundColor: "white", border: "none"}}><SoldRecipes></SoldRecipes></Button>
        <Button style={{backgroundColor: "white", border: "none"}}><WeekendOffers></WeekendOffers></Button>
        <Button style={{backgroundColor: "white", border: "none"}}><AboutUs></AboutUs></Button>
        <Button style={{backgroundColor: "white", border: "none"}}><JoinUs></JoinUs></Button>
        <Button style={{backgroundColor: "white", border: "none"}}><FreeGifts></FreeGifts></Button>
        <Button style={{backgroundColor: "white", border: "none"}}><Deals></Deals></Button>
      </div>
      <FirstPage
        headline="Meal Kits" 
        intro="Cooking great meals has never been easier" 
        choice="Choose from 28 new dinner recipes weekly and explore lunch, wine, market, and frozen meals. Orders close 9am Wed - pause anytime!"
        delivery="Get a weekly delivery of top quality, perfectly-portioned fresh produce, shipped in an insulated cold box, straight to your door."
        cookery="Get simple-to-follow recipes and create restaurant quality dishes in your own home with no more meal planning or food waste."
        mobile_app={<img style={{borderRadius: 50}} src={section3Picture} className="sec3-overlay" alt="logo3" />}
        week_menu="New recipes every week"
        order="Pick what you want to cook"
        get_started="Get started by selecting the default category that best suits your lifestyle - Adventurous Foodie, Quick & Easy, Calorie Conscious, Carb Conscious, Fan Faves, Veggie, or Simple & Save - and we’ll recommend the dishes that suit your dietary preferences. You will still be able to pick and choose your recipes as you like each week, but your default category covers you when you’re too busy to choose! Then choose how many people you’d typically like to cook for (1,2,3 or 4) and how many dishes you’d like to receive each week (2, 3, 4 or more). Change of plans? You can edit the number of dishes and portion size as you need or edit your default category at any time."
        going_pro="You’ll go pro in no time"
        chef="Cook like a chef, quick quick!"
        food_team="Our Food Team is made up of expert culinary talent who craft a new menu every week based on seasonality. Every recipe is designed to be simple, and ready in as little as 20 minutes. Discover new favourites, experiment with international cuisines and cook like a pro right at home."
        chef_picture={<img style={{borderRadius: 50}} src={section4Picture} className="sec4-overlay" alt="logo4" />}
        veg_picture={<img style={{borderRadius: 50}} src={section5Picture} className="sec5-overlay" alt="logo3" />}
        fresh="Always fresh"
        ethics="Ethically sourced whole ingredients, delivered to your door"
        delivery_mode="We like to keep it local, which is why we source our premium, ethically farmed ingredients from small-batch farmers and purveyors. We deliver ’em to your home or work address in an insulated box complete with reusable and recyclable ice packs – they’ll stay cold for up to 12 hours to keep your ingredients as fresh as the minute they were picked."
        subscription="A flexible subscription"
        kit_pause="Pause your Meal Kit at any time"
        holiday="Not in the mood to cook next week? No problem. You can pause your Meal kit plan if something else comes up or you need a break from cooking. Whenever you want, you can change your delivery address or the number of people you’re cooking for. Get in touch and we’ll walk you through it."
        kit_picture={<img style={{borderRadius: 50}} src={section6Picture} className="sec6-overlay" alt="logo6" />}
        menu="On the menu this week"
        balsamic_duck_breast={<img style={{borderRadius: 10}} src={section7Picture1} className="sec7-overlay1" alt="duck-breast" width="300" height="200"/>}
        beef_pancake={<img style={{borderRadius: 10}} src={section7Picture2} className="sec7-overlay2" alt="beef-pancake" width="300" height="200" />}
        beecon_charred_tomat={<img style={{borderRadius: 10}} src={section7Picture3} className="sec7-overlay3" alt="charred-tomat" width="300" height="200" />}
        herb_rice_pilaf={<img style={{borderRadius: 10}} src={section7Picture4} className="sec7-overlay4" alt="rice-pilaf" width="300" height="200" />}
        basil_pesto_beans={<img style={{borderRadius: 10}} src={section7Picture5} className="sec7-overlay5" alt="pesto-beans" width="300" height="200" />}
        spicy_ostrich={<img style={{borderRadius: 10}} src={section7Picture6} className="sec7-overlay6" alt="spicy-ostrich" width="300" height="200" />}
        chermoula_salsa={<img style={{borderRadius: 10}} src={section7Picture7} className="sec7-overlay7" alt="chermoula" width="300" height="200" />}
        pervian_ostrich={<img style={{borderRadius: 10}} src={section7Picture8} className="sec7-overlay8" alt="peru-ostrich" width="300" height="200" />}
        commitment="We’re committed to improving the food system and letting you discover incredible new seasonal produce."
        support="We support small-batch farmers and upskilling projects to give back to local communities with every order."
        homegrown="Homegrown meats and produce are what we’re all about and we source only the freshest local ingredients."
        story="UCOOK started when two friends, David Torr and Chris Verster Cohen, wanted to find a more convenient way to help people make dinner. Within two years, UCOOK took the country by storm as South Africa’s favourite meal-kit delivery company."
        product={<ul><li>MEAL</li><li>KITS</li><li>FROZEN</li><li>WINE</li><li>MARKETS</li></ul>}
        company={<ul><li>ABOUT</li><li>CAREERS</li><li>RECYCLE</li></ul>}
        support2={<ul><li>FAQ'S</li><li>CONTACT</li><li>m.nbwoge@gmail.com</li><li>07405900707</li></ul>}
        social1={<a href="https://apps.apple.com/us/app/ucook/id1669025266"><img style={{borderRadius: 5}} src={section10Picture1} className="sec10-overlay1" alt="peru-ostrich" width="100" height="40" /></a>}
        social2={<a href="https://play.google.com/store/apps/details?id=io.gonative.android.jaboxo&hl=en_ZA&gl=US&pli=1"><img style={{borderRadius: 5}} src={section10Picture2} className="sec10-overlay2" alt="peru-ostrich" width="100" height="30" /></a>}
        social3={<img style={{borderRadius: 5}} src={section10Picture3} className="sec10-overlay3" alt="peru-ostrich" width="25" height="25" />}
        social4={<img style={{borderRadius: 5}} src={section10Picture4} className="sec10-overlay4" alt="peru-ostrich" width="27" height="21" />}
        social5={<img style={{borderRadius: 5}} src={section10Picture5} className="sec10-overlay5" alt="peru-ostrich" width="27" height="21" />}
        social6={<img style={{borderRadius: 5}} src={section10Picture6} className="sec10-overlay6" alt="peru-ostrich" width="45" height="35" />}
      />
    </div>
    <fieldset class="footer">
      <legend></legend>
      <p style={
        {
          fontSize: "small", 
          color: "lightgray", 
          fontWeight: "bold", 
          textAlign: "left",
          variant: "outlinelight"
        }
      }
        >
          UCOOK. All rights reserved by The Supper Society Proprietary Limited | Liquor License: WCP/042073 | GAU/10615</p><p></p>
    </fieldset>
    </>
  );
}


export default App;

//* References
// Arthur Wilton (2021) Adding a Link to a Bootstrap Button with React Router, Medium. Available at: https://artwilton.medium.com/adding-a-link-to-a-bootstrap-button-with-react-router-57d2f6197588 (Accessed: 21 February 2025).
// bits-simplified (2023) How to Fix the “Objects are not valid as a React child” Error in React, Medium. Available at: https://medium.com/@simplecrypto22/how-to-fix-the-objects-are-not-valid-as-a-react-child-error-in-react-f5555908189d (Accessed: 19 February 2025).
// Chris Lord (2017) How To Create Horizontal Scrolling Containers, Code Burst IO. Available at: https://codeburst.io/how-to-create-horizontal-scrolling-containers-d8069651e9c6 (Accessed: 19 February 2025).
// Gift Egwuenu (2021) Programmatically Navigate with React Router, Teleric. Available at: https://www.telerik.com/blogs/programmatically-navigate-with-react-router (Accessed: 21 February 2025).
// Kader Biral (2024) Building a Custom Dropdown Component in React (Step by Step), Medium. Available at: https://kaderbiral26.medium.com/building-a-custom-dropdown-component-in-react-step-by-step-e12f4330fb58 (Accessed: 19 February 2025).
// Kamlesh (2023) How to Create a Responsive Horizontal Scrolling Card Slider in JavaScript, Test Karts. Available at: https://www.testkarts.com/blog/horizontal-card-scroll-with-arrow (Accessed: 19 February 2025). *//